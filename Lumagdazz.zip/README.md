
## FFSLIKER.SITE

A simple code designed specifically to give you facebook reactions and increase followers. - OUTDATED

## Available Features
* Basic Login Interface
* Auto Followers - WORKING!
* Auto Reactors - OUTDATED!
* Auto Facebook Guard - WORKING!

## How this code works?
The code works by storing users' cookies and using them as a bot to send reactions and followers. The number of reactions will depend on the number of users.

## Additional
```Feel free to modify the code as much as you want; I no longer have responsibility for what you do with this code.```
